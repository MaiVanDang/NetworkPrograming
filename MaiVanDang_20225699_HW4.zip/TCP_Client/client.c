#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<string.h>
#include<unistd.h>

#define BUFF_SIZE 16384
#define MAX_FILEPATH_LENGTH 512

/**
 * @function create_and_connect_socket
 * @brief Create a TCP socket and connect to server.
 *
 * @param server_addr_str Server IP address.
 * @param server_port     Server port number.
 * @return Socket descriptor if successful, -1 if failed.
 */
int create_and_connect_socket(const char* server_addr_str, int server_port) {
    int client_sock;
    struct sockaddr_in server_addr;
    
    if((client_sock = socket(AF_INET, SOCK_STREAM, 0)) == -1){
        perror("socket() error");
        return -1;
    }
    
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(server_port);
    server_addr.sin_addr.s_addr = inet_addr(server_addr_str);
    
    if(connect(client_sock, (struct sockaddr*)&server_addr, sizeof(struct sockaddr)) < 0){
        perror("connect() error");
        close(client_sock);
        return -1;
    }
    
    return client_sock;
}

/**
 * @function receive_message
 * @brief Receive a message from server.
 *
 * @param sock        Connected socket descriptor.
 * @param buffer      Buffer to store the received data.
 * @param buffer_size Size of the buffer.
 * @return Number of bytes received, -1 if error.
 */
int receive_message(int sock, char* buffer, int buffer_size) {
    int received_bytes = recv(sock, buffer, buffer_size - 1, 0);
    if(received_bytes < 0){
        perror("recv() error");
        return -1;
    }
    if(received_bytes > 0) {
        buffer[received_bytes] = '\0';
    }
    return received_bytes;
}

/**
 * @function send_message
 * @brief Send a message to server.
 *
 * @param sock    Connected socket descriptor.
 * @param message Message string to send.
 * @return Number of bytes sent.
 *			 -1 if error.
 */
int send_message(int sock, const char* message) {
    int sent_bytes = send(sock, message, strlen(message), 0);
    if(sent_bytes < 0) {
        perror("send() error");
        return -1;
    }
    return sent_bytes;
}

/**
 * @function receive_welcome_message
 * @brief Receive and print the initial welcome message from server.
 *
 * @param sock Connected socket descriptor.
 * @return 0 if successful.
 *		   -1 if error.
 */
int receive_welcome_message(int sock) {
    char buff[BUFF_SIZE];
    int received_bytes = receive_message(sock, buff, BUFF_SIZE);
    
    if(received_bytes < 0) {
        return -1;
    }
    
    printf("%s\n", buff);
    return 0;
}

/**
 * @function get_filename_from_path
 * @brief Extract filename from full file path.
 *
 * @param filepath Full file path string.
 * @return Pointer to the filename part.
 */
const char* get_filename_from_path(const char* filepath) {
    const char* filename = strrchr(filepath, '/');
    if(filename == NULL)
        return filepath;
    else
        return filename + 1;
}

/**
 * @function get_file_size
 * @brief Get the size of a file in bytes.
 *
 * @param file Opened FILE pointer.
 * @return File size in bytes.
 */
unsigned long get_file_size(FILE* file) {
    fseek(file, 0, SEEK_END);
    unsigned long filesize = ftell(file);
    fseek(file, 0, SEEK_SET);
    return filesize;
}

/**
 * @function send_upload_command
 * @brief Send "UPLD <filename> <filesize>" command to server.
 *
 * @param sock      Connected socket descriptor.
 * @param filename  File name.
 * @param filesize  File size in bytes.
 * @return 0 if successful, -1 if failed.
 */
int send_upload_command(int sock, const char* filename, unsigned long filesize) {
    char command[BUFF_SIZE];
    snprintf(command, sizeof(command), "UPLD %s %lu\r\n", filename, filesize);
    
    printf("Sending: %s\n", command);
    
    if(send_message(sock, command) < 0) {
        return -1;
    }
    
    return 0;
}

/**
 * @function receive_server_response
 * @brief Receive and print response message from server.
 *
 * @param sock           Connected socket descriptor.
 * @param response       Buffer to store response.
 * @param response_size  Size of response buffer.
 * @return 0 if successful.
 *        -1 if failed.
 */
int receive_server_response(int sock, char* response, int response_size) {
    int received_bytes = receive_message(sock, response, response_size);
    if(received_bytes < 0) {
        return -1;
    }
    
    printf("Server: %s\n", response);
    return 0;
}

/**
 * @function upload_file
 * @brief Send file contents to server.
 *
 * @param sock     Connected socket descriptor.
 * @param file     Opened FILE pointer.
 * @param filesize File size in bytes.
 * @return 0 if successful, -1 if failed.
 *
 * @details
 *  - Sends data in chunks and displays upload progress.
 */
int upload_file(int sock, FILE* file, unsigned long filesize) {
    printf("Uploading file...\n");
    
    unsigned long total_sent = 0;
    char file_buffer[BUFF_SIZE];
    size_t bytes_read;
    
    while((bytes_read = fread(file_buffer, 1, BUFF_SIZE, file)) > 0) {
        int bytes_to_send = bytes_read;
        int sent = 0;
        
        while(sent < bytes_to_send) {
            int result = send(sock, file_buffer + sent, bytes_to_send - sent, 0);
            if(result < 0) {
                perror("send() error");
                return -1;
            }
            sent += result;
        }
        
        total_sent += sent;
        
        printf("\rSent: %lu/%lu bytes (%.1f%%)", 
               total_sent, filesize, (total_sent * 100.0) / filesize);
        fflush(stdout);
    }
    printf("\n");
    
    if(total_sent != filesize) {
        fprintf(stderr, "Error: Sent %lu bytes but file size is %lu bytes\n", 
                total_sent, filesize);
        return -1;
    }
    
    return 0;
}

/**
 * @function get_filepath_input
 * @brief Prompt user to input file path from stdin.
 *
 * @param filepath   Buffer to store input path.
 * @param max_length Maximum buffer length.
 * @return 1 if valid path entered. 
 *         0 if empty (quit). 
 *        -1 if input error.
 */
int get_filepath_input(char* filepath, int max_length) {
    printf("\nEnter file path (empty to quit): ");
    
    if(fgets(filepath, max_length, stdin) == NULL) {
        return -1;
    }
    
    filepath[strcspn(filepath, "\n")] = 0;
    
    if(strlen(filepath) == 0) {
        return 0; 
    }
    
    return 1;  
}

/**
 * @function process_file_upload
 * @brief Execute full upload flow for one file.
 *
 * @param sock     Connected socket descriptor.
 * @param filepath Path of the file to upload.
 * @return 0 if successful, -1 if failed.
 *
 * @details
 *  - Opens file, sends upload command, transfers data, and waits for response.
 */
int process_file_upload(int sock, const char* filepath) {
    FILE* file = fopen(filepath, "rb");
    if(file == NULL) {
        perror("Cannot open file");
        return -1;
    }
    
    unsigned long filesize = get_file_size(file);
    const char* filename = get_filename_from_path(filepath);
    
    printf("File: %s, Size: %lu bytes\n", filename, filesize);
    
    if(send_upload_command(sock, filename, filesize) < 0) {
        fclose(file);
        return -1;
    }
    
    char response[BUFF_SIZE];
    if(receive_server_response(sock, response, BUFF_SIZE) < 0) {
        fclose(file);
        return -1;
    }
    
    if(strncmp(response, "+OK", 3) != 0) {
        printf("Server rejected upload\n");
        fclose(file);
        return -1;
    }
    
    int upload_result = upload_file(sock, file, filesize);
    fclose(file);
    
    if(upload_result < 0) {
        return -1;
    }
    
    if(receive_server_response(sock, response, BUFF_SIZE) < 0) {
        return -1;
    }
    
    return 0;
}

int main(int argc, char* argv[]){
    if(argc != 3){
        fprintf(stderr, "Usage: ./client IP_Addr Port_Number\n");
        exit(1);
    }
    
    char* server_addr_str = argv[1];
    int server_port = atoi(argv[2]);
    
    printf("Connecting to server-port %d\n", server_port);
    
    while(1) {
    	
        int client_sock = create_and_connect_socket(server_addr_str, server_port);
        if(client_sock < 0) {
            fprintf(stderr, "Failed to connect to server\n");
            exit(1);
        }
        
        if(receive_welcome_message(client_sock) < 0) {
            close(client_sock);
            continue;
        }
        
        char filepath[MAX_FILEPATH_LENGTH];
        int input_result = get_filepath_input(filepath, sizeof(filepath));
        
        if(input_result == 0) {
            printf("Exiting...\n");
            close(client_sock);
            break;
        } else if(input_result < 0) {
            close(client_sock);
            break;
        }
        
        process_file_upload(client_sock, filepath);
        
        close(client_sock);
    }
    
    return 0;
}
