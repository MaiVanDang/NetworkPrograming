#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<string.h>
#include<unistd.h>
#include<time.h>
#include<sys/stat.h>
#include<errno.h>

#define BUFF_SIZE 16384
#define BACKLOG 5
#define LOG_FILE "log_20225699.txt"
#define MAX_LOG_TIME_LENGTH 100
#define WELCOME_MSG "+OK Welcome to file server"
#define CONFIRM_MSG "+OK Please send file"
#define SUCCESS_MSG "+OK Successful upload"
#define ERROR_INVALID_CMD "-ERR Invalid command format"
#define ERROR_CREATE_FILE "-ERR Cannot create file"
#define ERROR_UPLOAD_FAIL "-ERR Upload failed"

/**
 * @function write_log
 * @brief Write client's request and result to a log file with timestamp.
 *
 * @param client_ip   Client's IP address.
 * @param client_port Client's port number.
 * @param request     The request message received from client.
 * @param result      The result or response message sent to client.
 *
 * @details
 *  - Log format: [dd/mm/yyyy HH:MM:SS]$IP:Port$request$result
 *  - File name is defined by LOG_FILE macro.
 */
void write_log(const char* client_ip, int client_port, const char* request, const char* result) {
    FILE* f = fopen(LOG_FILE, "a");
    if (f == NULL) {
        perror("Cannot open log file");
        return;
    }
    
    time_t current_time = time(NULL);
    struct tm *local_time = localtime(&current_time);
    char time_str[MAX_LOG_TIME_LENGTH];
    
    strftime(time_str, sizeof(time_str), "[%d/%m/%Y %H:%M:%S]", local_time);
    fprintf(f, "%s$%s:%d$%s$%s\n", time_str, client_ip, client_port, request, result);
    
    fclose(f);
}

/**
 * @function create_directory_if_not_exists
 * @brief Check if a directory exists; if not, create it.
 *
 * @param directory The directory path to check or create.
 * @return 0 if successful.
 *	       -1 if failed to create directory.
 */
int create_directory_if_not_exists(const char* directory) {
    struct stat st = {0};
    if (stat(directory, &st) == -1) {
        if (mkdir(directory, 0700) == -1) {
            perror("mkdir() error");
            return -1;
        }
    }
    return 0;
}

/**
 * @function create_and_bind_socket
 * @brief Create a TCP listening socket and bind it to a specific port.
 *
 * @param port The server port number.
 * @return Socket descriptor if successful, -1 if error occurs.
 *
 * @details
 *  - Uses SO_REUSEADDR to allow reusing the address.
 *  - Calls bind() and listen() for passive socket setup.
 */
int create_and_bind_socket(int port) {
    int listen_sock;
    struct sockaddr_in server_addr;
    
    if((listen_sock = socket(AF_INET, SOCK_STREAM, 0)) == -1){
        perror("socket() error");
        return -1;
    }
    
    int opt = 1;
    if(setsockopt(listen_sock, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0){
        perror("setsockopt() error");
        close(listen_sock);
        return -1;
    }
    
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    
    if(bind(listen_sock, (struct sockaddr*)&server_addr, sizeof(server_addr)) == -1){
        perror("bind() error");
        close(listen_sock);
        return -1;
    }
    
    if(listen(listen_sock, BACKLOG) == -1){
        perror("listen() error");
        close(listen_sock);
        return -1;
    }
    
    return listen_sock;
}

/**
 * @function send_message
 * @brief Send a message to the connected client.
 *
 * @param sock    Socket descriptor of the client connection.
 * @param message Message string to send.
 * @return Number of bytes sent, or -1 if failed.
 */
int send_message(int sock, const char* message) {
    int bytes_sent = send(sock, message, strlen(message), 0);
    if(bytes_sent < 0) {
        perror("send() error");
        return -1;
    }
    return bytes_sent;
}

/**
 * @function receive_data
 * @brief Receive a data message from client.
 *
 * @param sock         Socket descriptor.
 * @param buffer       Buffer to store received data.
 * @param buffer_size  Size of the buffer.
 * @return Number of bytes received, -1 if error, 0 if closed.
 */
int receive_data(int sock, char* buffer, int buffer_size) {
    int received_bytes = recv(sock, buffer, buffer_size - 1, 0);
    if(received_bytes < 0) {
        perror("recv() error");
        return -1;
    }
    if(received_bytes > 0) {
        buffer[received_bytes] = '\0';
    }
    return received_bytes;
}

/**
 * @function parse_upload_command
 * @brief Parse the "UPLD <filename> <filesize>" command.
 *
 * @param recv_data The received raw command string.
 * @param filename  Output buffer to store filename.
 * @param filesize  Pointer to store parsed file size.
 * @return 0 if valid, -1 if invalid or command not recognized.
 */
int parse_upload_command(const char* recv_data, char* filename, unsigned long* filesize) {
    char command[10];
    char clean_data[BUFF_SIZE];
    strcpy(clean_data, recv_data);
    
    clean_data[strcspn(clean_data, "\r\n")] = 0;
    
    int parsed = sscanf(clean_data, "%s %s %lu", command, filename, filesize);
    
    if(parsed != 3 || strcmp(command, "UPLD") != 0) {
        return -1;
    }
    return 0;
}

/**
 * @function receive_file
 * @brief Receive file data from client and save it to disk.
 *
 * @param sock      Connected socket descriptor.
 * @param filepath  Destination file path.
 * @param filesize  Expected file size.
 * @return 0 if successful, -1 if error or incomplete file transfer.
 *
 * @details
 *  - Receives data in chunks and writes to file.
 *  - Displays progress percentage.
 */
int receive_file(int sock, const char* filepath, unsigned long filesize) {
    FILE* file = fopen(filepath, "wb");
    if(file == NULL) {
        perror("fopen() error");
        return -1;
    }
    
    unsigned long total_received = 0;
    char file_buffer[BUFF_SIZE];
    
    while(total_received < filesize) {
        int to_receive = (filesize - total_received > BUFF_SIZE) ? 
                         BUFF_SIZE : (filesize - total_received);
        int received_bytes = recv(sock, file_buffer, to_receive, 0);
        
        if(received_bytes <= 0) {
            if(received_bytes == 0)
                printf("Connection closed unexpectedly\n");
            else
                perror("recv() error");
            fclose(file);
            return -1;
        }
        
        fwrite(file_buffer, 1, received_bytes, file);
        total_received += received_bytes;
        
        printf("\rReceiving: %lu/%lu bytes (%.1f%%)", 
               total_received, filesize, (total_received * 100.0) / filesize);
        fflush(stdout);
    }
    printf("\n");
    
    fclose(file);
    
    if(total_received != filesize) {
        return -1;
    }
    return 0;
}

/**
 * @function handle_file_upload
 * @brief Handle one file upload request from client.
 *
 * @param conn_sock  Connected client socket.
 * @param client_ip  Client's IP address.
 * @param client_port Client's port.
 * @param directory  Destination directory for uploaded files.
 *
 * @details
 *  - Waits for "UPLD <filename> <filesize>".
 *  - Confirms, receives file, and logs result.
 */
void handle_file_upload(int conn_sock, const char* client_ip, int client_port, 
                       const char* directory) {
    char recv_data[BUFF_SIZE];
    
    int received_bytes = receive_data(conn_sock, recv_data, BUFF_SIZE);
    if(received_bytes <= 0) {
        if(received_bytes == 0)
            printf("Connection closed by client\n");
        return;
    }
    
    printf("Received: %s\n", recv_data);
    
    char filename[256];
    unsigned long filesize;
    if(parse_upload_command(recv_data, filename, &filesize) < 0) {
        send_message(conn_sock, ERROR_INVALID_CMD);
        write_log(client_ip, client_port, recv_data, ERROR_INVALID_CMD);
        return;
    }
    
    if(send_message(conn_sock, CONFIRM_MSG) < 0) {
        return;
    }
    
    char filepath[512];
    snprintf(filepath, sizeof(filepath), "%s/%s", directory, filename);
    
    int result = receive_file(conn_sock, filepath, filesize);
    
    char log_request[512];
    snprintf(log_request, sizeof(log_request), "UPLD %s %lu\\r\\n", filename, filesize);
    
    const char* result_msg;
    if(result == 0) {
        result_msg = SUCCESS_MSG;
        printf("File %s uploaded successfully (%lu bytes)\n", filename, filesize);
    } else {
        result_msg = ERROR_UPLOAD_FAIL;
        printf("File upload failed\n");
        remove(filepath);
    }
    
    send_message(conn_sock, result_msg);
    write_log(client_ip, client_port, log_request, result_msg);
}

/**
 * @function handle_client_connection
 * @brief Handle a new client connection session.
 *
 * @param conn_sock   Connected client socket.
 * @param client_ip   Client IP address.
 * @param client_port Client port.
 * @param directory   Directory to save uploaded files.
 *
 * @details
 *  - Sends welcome message.
 *  - Invokes file upload handling.
 *  - Closes connection afterward.
 */
void handle_client_connection(int conn_sock, const char* client_ip, 
                              int client_port, const char* directory) {
    printf("You got a connection from %s:%d\n", client_ip, client_port);
    
    if(send_message(conn_sock, WELCOME_MSG) < 0) {
        close(conn_sock);
        return;
    }
    
    write_log(client_ip, client_port, "CONNECT", WELCOME_MSG);
    
    handle_file_upload(conn_sock, client_ip, client_port, directory);
    
    close(conn_sock);
}

int main(int argc, char* argv[]){
    if (argc != 3) {
        fprintf(stderr, "Usage: ./server Port_Number Directory_name\n");
        exit(1);
    }
    
    int port = atoi(argv[1]);
    char* directory = argv[2];
    
    if(create_directory_if_not_exists(directory) < 0) {
        exit(1);
    }
    
    int listen_sock = create_and_bind_socket(port);
    if(listen_sock < 0) {
        exit(1);
    }
    
    printf("Server started at port %d!\n", port);
    printf("Storage directory: %s\n", directory);
    printf("Waiting for connections...\n\n");
    
    while(1) {
        struct sockaddr_in client_addr;
        socklen_t sin_size = sizeof(struct sockaddr_in);
        
        int conn_sock = accept(listen_sock, (struct sockaddr*)&client_addr, &sin_size);
        if(conn_sock == -1) {
            perror("accept() error");
            continue;
        }
        
        char client_ip[INET_ADDRSTRLEN];
        if(inet_ntop(AF_INET, &client_addr.sin_addr, client_ip, INET_ADDRSTRLEN) == NULL) {
            perror("inet_ntop() error");
            close(conn_sock);
            continue;
        }
        
        int client_port = ntohs(client_addr.sin_port);
        
        handle_client_connection(conn_sock, client_ip, client_port, directory);
    }
    
    close(listen_sock);
    return 0;
}
